<?php

namespace App\Enums;

enum EggFormat: string
{
    case YAML = 'yaml';
    case JSON = 'json';
}
