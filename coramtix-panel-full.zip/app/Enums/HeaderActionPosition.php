<?php

namespace App\Enums;

enum HeaderActionPosition: string
{
    case Before = 'before';
    case After = 'after';
}
