<?php

namespace App\Enums;

enum HeaderWidgetPosition: string
{
    case Before = 'before';
    case After = 'after';
}
