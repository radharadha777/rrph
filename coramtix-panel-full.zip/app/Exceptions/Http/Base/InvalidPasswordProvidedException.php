<?php

namespace App\Exceptions\Http\Base;

use App\Exceptions\DisplayException;

class InvalidPasswordProvidedException extends DisplayException {}
