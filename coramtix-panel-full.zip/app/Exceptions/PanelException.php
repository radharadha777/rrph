<?php

namespace App\Exceptions;

class PanelException extends \Exception {}
