<?php

namespace App\Exceptions\Repository;

use Exception;

class FileExistsException extends Exception {}
