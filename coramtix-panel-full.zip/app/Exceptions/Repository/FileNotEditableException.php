<?php

namespace App\Exceptions\Repository;

use Exception;

class FileNotEditableException extends Exception {}
