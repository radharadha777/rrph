<?php

namespace App\Exceptions\Service\Egg;

use App\Exceptions\DisplayException;

class HasChildrenException extends DisplayException {}
