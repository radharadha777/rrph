<?php

namespace App\Exceptions\Service;

use App\Exceptions\DisplayException;

class InvalidFileUploadException extends DisplayException {}
