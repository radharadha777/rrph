<?php

namespace App\Exceptions\Service\Node;

use App\Exceptions\DisplayException;

class ConfigurationNotPersistedException extends DisplayException {}
