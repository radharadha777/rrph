<?php

namespace App\Exceptions\Service\Subuser;

use App\Exceptions\DisplayException;

class UserIsServerOwnerException extends DisplayException {}
