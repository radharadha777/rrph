<?php

namespace App\Filament\Components\Tables\Columns;

use Filament\Tables\Columns\Column;

class ServerEntryColumn extends Column
{
    protected string $view = 'livewire.columns.server-entry-column';
}
