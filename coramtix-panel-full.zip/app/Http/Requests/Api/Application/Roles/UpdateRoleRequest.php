<?php

namespace App\Http\Requests\Api\Application\Roles;

class UpdateRoleRequest extends StoreRoleRequest {}
