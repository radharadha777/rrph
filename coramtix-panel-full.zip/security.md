# Security Policy

## Supported Versions

We currently only support these versions:

| Version | Supported          |
| ------- | ------------------ |
| 3.x     | :white_check_mark: |
| < 3.x   | :x:                |

## Reporting a Vulnerability

Please report any vulnerabilities directly to team@coramtix.dev

We will respond within 72 hours with a timeline of when to expect a resolution.
